/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package volumeandsurface;

import java.util.Scanner;
//All prism like shapes will be in this class

public class Prisms extends VolumeAndSurface {

    static Scanner input = new Scanner(System.in);
    //The three variables needed, had to be static due to creation of object later
    static float len;
    static float hei;
    static float wid;
    //Method is for basic shapes, such as cube, square/rectangle based prisms

    @Override
    public float surfaceCalc() {
        float surFac = ((Prisms.wid * Prisms.hei) + (Prisms.hei * Prisms.len) + (Prisms.wid*Prisms.len))*2;
        return surFac;
    }
    //public float 
            //Method for triangular based prisms
//            @Override
//
//    public float surfaceCalc() {
//        
//
//    }

    public Prisms(float length, float height, float width) {

        setWidth(width);
        setHeight(height);
        setLength(length);

    }
    //attempting to create object within method, as well as do mathematicl operations

    public static void CubeStuff() {
        len = input.nextFloat();
        hei = input.nextFloat();
        wid = input.nextFloat();
        Prisms Cube = new Prisms(len, hei, wid);
        System.out.println(Cube.surfaceCalc());

        // System.out.println(Prisms.len+ "+" + Prisms.hei);
    }

}
