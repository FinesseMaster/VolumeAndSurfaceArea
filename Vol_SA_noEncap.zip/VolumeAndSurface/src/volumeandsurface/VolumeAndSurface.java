/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package volumeandsurface;

/**
 *
 * @author Shadow
 */
public class VolumeAndSurface {
    //Encapsulated these variables
     float surArea;
   float volume;
 float height;
    float length;
    float base;
   float radius;
     float width;
     float slanthei;
    
    /*attempt to use encapsulation
    public  void setHeight(float setHei){
    height=setHei;
        
        }
    
     public void setWidth(float setWid){
        width=setWid;
    }
      
  
    public void setRadius(float setRad){
        radius=setRad;
        
        }
    public void setLength(float setLen){
        
        length=setLen;
    }
    */
    public float surfaceCalc(){
        return surArea;    
    }
    
    public float volumeCalc(){
        return volume;
    }
    
    public static void main(String[] args) {
        
        
    RectPrism myPrism = new RectPrism();
    myPrism.surfaceCalc(0, 0, 0);
    myPrism.volumeCalc(0, 0, 0);
    

    }
    
}
