/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package volumeandsurface;

import java.util.Scanner;
//All prism like shapes will be in this class

public class RectPrism extends VolumeAndSurface {

     Scanner input = new Scanner(System.in);
    
    
    public RectPrism(){
         System.out.print("Please input a length value: ");
       this.length=input.nextFloat();
       
        System.out.print("Please input a height value: ");
          this.height=input.nextFloat();
       
         System.out.print("Please input a width value: ");
         this. width=input.nextFloat();
        
    }
    //Methods is for basic shapes, such as cube, square/rectangle based prisms
     
    public void surfaceCalc(float width, float height, float length) {
          
       
         this.surArea= ((this.width*this.height)+ (this.length*this.height)+ (this.length*this.width))*2;
         System.out.println("The surface area is " + this.surArea);
         
       
    }
    
    public void volumeCalc(float width, float height, float length){
        this.volume=this.width*this.length*this.height;
        System.out.println(this.volume);
        
    }
   
    } 

 
    

    
    
